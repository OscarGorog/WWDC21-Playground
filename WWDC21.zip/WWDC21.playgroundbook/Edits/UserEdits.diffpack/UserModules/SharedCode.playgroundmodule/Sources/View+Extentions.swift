import SwiftUI

public extension View {
    /// Removes a view based on a boolean
    @ViewBuilder func removeView(_ shouldRemove: Bool) -> some View {
        if !shouldRemove {
            self
        }
    }
    
    /// Allows a transform to be applied based on a boolean
    @ViewBuilder func `if`<Transform: View>(_ condition: Bool, transform: (Self) -> Transform) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}
