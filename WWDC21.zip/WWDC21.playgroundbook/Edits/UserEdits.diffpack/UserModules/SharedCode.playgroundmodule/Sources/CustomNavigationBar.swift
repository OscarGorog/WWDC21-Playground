import SwiftUI

/// A custom navigation bar that can display a view on the left and right
public struct CustomNavigationBar<Left: View, Right: View>: View {
    private let leftContent: Left
    private let rightContent: Right
    
    public init(@ViewBuilder leftContent: () -> Left, @ViewBuilder rightContent: () -> Right) {
        self.leftContent = leftContent()
        self.rightContent = rightContent()
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            Spacer()
                .frame(height: 14)
            HStack {
                leftContent
                Spacer()
                rightContent
            }
            .padding(.horizontal)
            Spacer()
                .frame(height: 14)
            Divider()
        }
    }
}

/// Allows the `CustomNavigationBar` to be displayed with only a right view
public extension CustomNavigationBar where Left == EmptyView {
    init(@ViewBuilder rightContent: () -> Right) {
        self.init(leftContent: { EmptyView() }, rightContent: rightContent)
    }
}
