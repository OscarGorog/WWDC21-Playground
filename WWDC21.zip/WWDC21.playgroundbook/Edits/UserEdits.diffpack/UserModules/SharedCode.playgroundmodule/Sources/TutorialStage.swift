import Foundation

/// A protocol that allows us to easily create an enum used for a `TutorialManager`
public protocol TutorialStage: RawRepresentable where RawValue == Int {
    var explanation: String { get }
    var canGoBack: Bool { get }
    var canGoForward: Bool { get }
}
