import SwiftUI

/// A small bar that can be placed at the top of a view with a title and optionally, a subtitle
public struct ExplanationView: View {
    
    @Binding public var title: String
    @Binding public var subtitle: String?
    
    // For some bizarre reason Swift Playgrounds can't autogenerate a initializer for this class so we have to manually create one
    public init(title: Binding<String>, subtitle: Binding<String?> = .constant(nil)) {
        self._title = title
        self._subtitle = subtitle
    }
    
    public var body: some View {
        HStack(spacing: 10) {
            Spacer()
            VStack(spacing: 2) {
                Text(title)
                    .font(.headline)
                if let subtitle = subtitle {
                    Text(subtitle)
                        .font(.subheadline)
                        .animation(.default)
                }
            }
            .foregroundColor(.black)
            .lineLimit(nil)
            .multilineTextAlignment(.center)
            Spacer()
        }.bubbleBackground()
    }
}
