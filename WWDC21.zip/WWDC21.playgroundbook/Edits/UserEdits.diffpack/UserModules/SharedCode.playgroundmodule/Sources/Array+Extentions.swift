import Foundation

public extension Array {
    /// Subscripts the array and returns `nil` if the index is out of range
    subscript(safeIndex index: Index) -> Element? {
        guard index >= 0, index < endIndex else { return nil }
        return self[index]
    }
    
    /// Appends elements to an array and returns the new array
    func appending(_ newElements: [Element]) -> [Element] {
        var newArray = self
        newArray += newElements
        return newArray
    }
}
