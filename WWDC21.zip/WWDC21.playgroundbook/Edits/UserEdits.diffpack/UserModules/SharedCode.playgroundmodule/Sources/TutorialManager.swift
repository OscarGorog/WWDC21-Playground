import Foundation

/// A protocol that allows us to easily create tutorial managers based of a `TutorialStage` enum
public protocol TutorialManager: ObservableObject {
    associatedtype Stage: TutorialStage
    
    var currentStage: Stage { get set }
}

public extension TutorialManager {
    var previousStage: Stage? {
        return Stage(rawValue: currentStage.rawValue - 1)
    }
    
    var nextStage: Stage? {
        return Stage(rawValue: currentStage.rawValue + 1)
    }
    
    /// Makes sure we can only go back if the previous stage is available
    func canGoBack() -> Bool {
        return previousStage != nil && currentStage.canGoBack
    }
    
    /// Makes sure we can only go forward if the next stage is available
    func canGoForward() -> Bool {
        return nextStage != nil && currentStage.canGoForward
    }
    
    /// Goes back one stage
    func goBack() {
        // We can force unwrap here because the "Go Back" button will only be enabled if the `canGoBack` function is not nil
        currentStage = previousStage!
    }
    
    /// Goes forward one stage
    func goForward() {
        // We can force unwrap here because the "Next" button will only be enabled if the `canGoForward` function is not nil
        currentStage = nextStage!
    }
}
