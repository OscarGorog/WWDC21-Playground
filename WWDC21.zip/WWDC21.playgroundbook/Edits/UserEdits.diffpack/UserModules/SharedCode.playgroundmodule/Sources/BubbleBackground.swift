import SwiftUI

/// Applies a background that looks like a bubble
public struct BubbleBackground: ViewModifier {
    public func body(content: Content) -> some View {
        content
            .padding()
            .background(Color.white.opacity(0.8))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

/// Allows the `BubbleBackground` modifier to be easily applied
public extension View {
    func bubbleBackground() -> some View {
        self.modifier(BubbleBackground())
    }
}
