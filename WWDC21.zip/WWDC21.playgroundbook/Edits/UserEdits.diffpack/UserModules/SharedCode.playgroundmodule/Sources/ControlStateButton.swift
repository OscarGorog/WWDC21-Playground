import SwiftUI

/// A button that performs functions on a `TutorialManager`
public struct ControlStateButton<Manager: TutorialManager>: View {
    
    /// The type that the button can be displayed as
    public enum ButtonType: String {
        case goBack = "Go Back"
        case next = "Next"
    }
    public var buttonType: ButtonType
    @Binding public var isEnabled: Bool
    @ObservedObject public var tutorialManager: Manager
    
    // For some bizarre reason Swift Playgrounds can't autogenerate a initializer for this class so we have to manually create one
    public init(buttonType: ButtonType, isEnabled: Binding<Bool>, tutorialManager: Manager) {
        self.buttonType = buttonType
        self._isEnabled = isEnabled
        self.tutorialManager = tutorialManager
    }
    
    public var body: some View {
        Button(action: {
            switch buttonType {
            case .goBack:
                tutorialManager.goBack()
            case .next:
                tutorialManager.goForward()
            }
        }) {
            Text(buttonType.rawValue)
                .foregroundColor(.white)
                .font(.title3)
                .fontWeight(.semibold)
                .padding()
                .background(isEnabled ? Color.blue : Color.gray)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }.disabled(!isEnabled)
    }
}
