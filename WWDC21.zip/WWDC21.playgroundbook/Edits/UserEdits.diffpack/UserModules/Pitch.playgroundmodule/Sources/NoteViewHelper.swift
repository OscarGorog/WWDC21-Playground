import Foundation

/// A struct that contains a note and some other variables to help create the scrolling notes view
public struct NoteViewHelper: Identifiable, Equatable {
    
    public var id: UUID
    var note: Note!
    var isCorrect: Bool!
    
    /// Create the `NoteViewHelper` from a `Note`
    public init(note: Note) {
        self.id = UUID()
        self.note = note
        self.isCorrect = false
    }
}
