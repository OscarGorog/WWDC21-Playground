import ARKit
import SwiftUI
import SharedCode

/// Manages everything the user sees
public struct PitchTeacherView: View {
    
    /// Manages the current displayed sheet for the view. Since you cannot use multiple sheet modifiers on one view we have to create an enum that holds the current sheet or `nil` if there isn't one active
    private enum ActiveSheet: Int, Identifiable {
        var id: Int {
            return rawValue
        }
        
        case selectSong = 0, finishedPlayground
    }
    /// Manages the current displayed alert for the view. Since you cannot use multiple alert modifiers on one view we have to create an enum that holds the current alert or `nil` if there isn't one active
    private enum ActiveAlert: Int, Identifiable {
        var id: Int {
            return rawValue
        }
        
        case cantFindVerticalPlane = 0, hint
    }
    @ObservedObject public var arViewState: ARViewState
    @ObservedObject public var pitchTutorialManager = PitchTutorialManager()
    @ObservedObject public var playTheSongGame: PlayTheSongGame
    @ObservedObject public var solfaGame = SolfaGame()
    @State private var activeSheet: ActiveSheet?
    @State private var activeAlert: ActiveAlert?
    @State private var explanationText = ""
    @State private var canGoBack = false
    @State private var canGoForward = true
    @State private var isShowingLargeCurrentNote = true
    @State private var hintMessage = ""
    @State private var didSkipAddingSolfaSignImage = false
    
    public init() {
        // Create the view state and pass it to two objects
        let arViewState = ARViewState()
        self.arViewState = arViewState
        self.playTheSongGame = PlayTheSongGame(arViewState: arViewState)
    }
    
    public var body: some View {
        ZStack {
            cameraView
            if solfaGame.isPlaying {
                largeSolfaNoteView
            }
            VStack {
                if solfaGame.isPlaying {
                    solfaGameScoringView
                } else if activeSheet == nil {
                    ExplanationView(title: $explanationText,
                                    subtitle: $arViewState.arStatusDescription)
                    if pitchTutorialManager.currentStage == .setupSolfaImage {
                        verticalPlaneButton
                    } else if pitchTutorialManager.currentStage == .solfaHandSignsBackground || pitchTutorialManager.currentStage == .actualHandSigns {
                        solfaSignsImage
                    }
                    if playTheSongGame.isPlaying {
                        playTheSomeGameNotesView
                    }
                }
                Spacer()
                if !arViewState.isSettingUpScene && !solfaGame.isPlaying && activeSheet == nil {
                    HStack {
                        ControlStateButton(buttonType: .goBack,
                                           isEnabled: $canGoBack,
                                           tutorialManager: pitchTutorialManager)
                        Spacer()
                        ControlStateButton(buttonType: .next,
                                           isEnabled: $canGoForward,
                                           tutorialManager: pitchTutorialManager)
                    }.environmentObject(pitchTutorialManager)
                }
            }.padding()
        }.onReceive(pitchTutorialManager.$currentStage) { (currentStage) in
            explanationText = currentStage.explanation
            canGoBack = pitchTutorialManager.canGoBack()
            canGoForward = pitchTutorialManager.canGoForward()
            
            if currentStage == .playTheSongGame {
                activeSheet = .selectSong
            } else if currentStage == .animateMoveToSolfaStage {
                arViewState.pianoScene.actions.moveToSolfaStageCompleted.onAction = { (_) in
                    canGoForward = true
                }
                arViewState.pianoScene.notifications.moveToSolfaStage.post()
            } else if currentStage == .setupSolfaImage {
                arViewState.setupCoachingView(with: .verticalPlane)
            } else if currentStage == .solfaGame {
                solfaGame.startGame()
            }
        }
        .onReceive(arViewState.$isSettingUpScene) { (isSettingUp) in
            if !isSettingUp {
                pitchTutorialManager.goForward()
            }
        }
        .onReceive(playTheSongGame.$isPlaying) { (isPlaying) in
            if !isPlaying && pitchTutorialManager.currentStage == .playTheSongGame {
                pitchTutorialManager.goForward()
            }
        }
        .onReceive(solfaGame.$isPlaying, perform: { (isPlaying) in
            if !isPlaying && pitchTutorialManager.currentStage == .solfaGame {
                activeSheet = .finishedPlayground
            }
        })
        .onReceive(solfaGame.$currentNote, perform: { (currentNote) in
            isShowingLargeCurrentNote = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                isShowingLargeCurrentNote = false
            }
        })
        .onChange(of: activeSheet, perform: { (activeSheet) in
            if activeSheet == .finishedPlayground {
                solfaGame.videoPreviewView.stopCamera()
            }
        })
        .alert(item: $activeAlert) { (activeAlert) in
            switch activeAlert {
            case .cantFindVerticalPlane:
                return Alert(title: Text("Can't find a vertical plane?"), message: Text("Some models of iPad seem to not be able to find vertical planes very well. If you'r having trouble detecting a plane, you can skip this step and view the solfa signs image later"), primaryButton: .default(Text("Keep Trying")), secondaryButton: .default(Text("Skip This Step"), action: {
                    didSkipAddingSolfaSignImage = true
                    arViewState.disableCoachingView()
                }))
            case .hint:
                return Alert(title: Text("Hint"), message: Text(hintMessage), dismissButton: .default(Text("OK"), action: {
                    solfaGame.startGame()
                }))
            }
        }
        .sheet(item: $activeSheet) { (activeSheet) in
            switch activeSheet {
            case .selectSong:
                SelectSongView(dismissAction: { (selectedSong) in
                    explanationText = selectedSong.rawValue
                    playTheSongGame.startGame(song: selectedSong)
                    self.activeSheet = nil
                })
            case .finishedPlayground:
                FinishedPlaygroundView(score: solfaGame.currentScore, playAgainBlock: {
                    solfaGame.startGame()
                    self.activeSheet = nil
                })
            }
        }
    }
    
    private var cameraView: some View {
        Group {
            if pitchTutorialManager.currentStage == .solfaGame {
                SolfaSignRecogniserVideoView(videoPreviewView: solfaGame.videoPreviewView)
            } else {
                ARViewContainer(arViewState: arViewState)
                
            }
        }.edgesIgnoringSafeArea(.all)
    }
    
    private var largeSolfaNoteView: some View {
        VStack {
            if !isShowingLargeCurrentNote {
                Spacer()
            }
            HStack {
                VStack {
                    Text(solfaGame.currentNote.rawValue)
                        .foregroundColor(.black)
                        .font(.system(size: isShowingLargeCurrentNote ? 50 : 30, weight: .semibold, design: .default))
                    if !isShowingLargeCurrentNote {
                        Button(action: {
                            solfaGame.pauseGame()
                            hintMessage = solfaGame.currentNote.hint
                            activeAlert = .hint
                        }) {
                            Text("Hint")
                        }
                    }
                }.bubbleBackground()
                if !isShowingLargeCurrentNote {
                    Spacer()
                }
            }
        }
        .animation(.easeInOut)
        .padding()
    }
    
    private var solfaGameScoringView: some View {
        VStack {
            ExplanationView(title: .constant("There was an error with the solfa game. Please try restrating the playground."),
                            subtitle: $solfaGame.errorDescription)
                .removeView(solfaGame.errorDescription == nil)
            HStack {
                VStack {
                    Text("\(solfaGame.currentScore)")
                        .foregroundColor(.green)
                        .font(.headline)
                    Text("Score")
                        .foregroundColor(.black)
                        .font(.subheadline)
                }.bubbleBackground()
                Spacer()
                VStack {
                    Text("\(solfaGame.timeLeft)")
                        .foregroundColor(.green)
                        .font(.headline)
                    Text("Time Remaining")
                        .foregroundColor(.black)
                        .font(.subheadline)
                }.bubbleBackground()
            }
        }
    }
    
    private var playTheSomeGameNotesView: some View {
        ScrollView(.horizontal) {
            LazyHStack {
                ForEach(playTheSongGame.notes) { (noteViewHelper) in
                    NoteView(noteViewHelper: noteViewHelper)
                }
            }.fixedSize()
        }
    }
    
    private var verticalPlaneButton: some View {
        // There seems to be an issue where a vertical plane cannot be detected so we can give the user an option to skip this step
        HStack {
            Spacer()
            Button(action: {
                activeAlert = .cantFindVerticalPlane
            }, label: {
                Text("Can't find a vertical plane?")
                    .font(.headline)
            }).bubbleBackground()
        }
    }
    
    private var solfaSignsImage: some View {
        // If the user failed to add the image in AR give them an option to view it here instead
        HStack {
            Spacer()
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "Solfa Hand Signs.png"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                Text("Solfa Signs")
                    .font(.headline)
                    .foregroundColor(.black)
            }.bubbleBackground()
        }
    }
}
