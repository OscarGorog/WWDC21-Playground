import SwiftUI
import RealityKit

/// Allows the `ARView` to be displayed in SwiftUI
public struct ARViewContainer: UIViewRepresentable {
    
    @ObservedObject var arViewState: ARViewState
    
    public func makeUIView(context: Context) -> ARView {
        arViewState.setupCoachingView(with: .horizontalPlane)
        return arViewState.arView
    }
    
    public func updateUIView(_ uiView: ARView, context: Context) { }
}
