import Foundation

/// The main 7 solfege notes
public enum SolfaNote: String, CaseIterable {
    case `do` = "Do"
    case re = "Re"
    case mi = "Mi"
    case fa = "Fa"
    case so = "So"
    case la = "La"
    case ti = "Ti"
    
    /// Gives a hint for the note
    public var hint: String {
        switch self {
        case .do:
            return "A fist"
        case .re:
            return "A slanted hand"
        case .mi:
            return "A horizontal flat hand"
        case .fa:
            return "Thumbs down"
        case .so:
            return "A vertical flat hand"
        case .la:
            return "A hand without bones"
        case .ti:
            return "Like you'r pointing at something"
        }
    }
}
