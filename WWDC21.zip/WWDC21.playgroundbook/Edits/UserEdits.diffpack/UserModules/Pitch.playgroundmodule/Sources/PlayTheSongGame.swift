import SwiftUI
import Foundation

/// Manages the song game
public class PlayTheSongGame: ObservableObject {
    
    // MARK: - Variables
    private var arViewState: ARViewState!
    @Published public var isPlaying = false
    @Published public var notes = [NoteViewHelper]()
    
    // MARK: - Initialisers
    init(arViewState: ARViewState) {
        self.arViewState = arViewState
    }
    
    // MARK: - Functions
    
    /// Start the game with the given song
    public func startGame(song: Song) {
        // Make sure were not playing
        guard !isPlaying else { return }
        
        // Set the related variables
        isPlaying = true
        notes = song.notes.map(NoteViewHelper.init)
        
        // Set an action that is triggered if a note on the piano is played
        arViewState.pianoScene.actions.notePlayed.onAction = { [self] (entity) in
            guard let entity = entity,
                  let note = Note(rawValue: entity.name), // The entity name is defined in the Reality Composer so we can directly initialise a `Note` from it
                  let noteToPlay = notes.first else { return }
            if note == noteToPlay.note {
                withAnimation(.easeInOut(duration: 0.25)) {
                    // Set the first note to correct. This also makes it light up green on the view
                    notes[0].isCorrect = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        // Remove the correct note
                        notes.removeAll(where: { $0.id == noteToPlay.id })
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        // If the notes are empty then the game is finished
                        if notes.isEmpty {
                            arViewState.pianoScene.actions.notePlayed.onAction = nil
                            isPlaying = false
                        }
                    }
                }
            }
        }
    }
}
