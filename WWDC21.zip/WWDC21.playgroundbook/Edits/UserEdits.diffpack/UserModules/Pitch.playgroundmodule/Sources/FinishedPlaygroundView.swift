import SwiftUI
import SharedCode

/// A view that congratulates the user on completing the playground and allows them to play the solfa game again
public struct FinishedPlaygroundView: View {
    
    public var score: Int
    public var playAgainBlock: () -> Void
    
    public var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .edgesIgnoringSafeArea(.all)
            VStack {
                CustomNavigationBar(leftContent: {
                    Text("Score: \(score)")
                        .fontWeight(.semibold)
                }, rightContent: {
                    Button(action: playAgainBlock, label: {
                        Text("Play Again")
                            .foregroundColor(.blue)
                            .fontWeight(.semibold)
                    })
                })
                Spacer()
                VStack {
                    Image(systemName: "music.note")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 100)
                        .foregroundColor(.blue)
                    Text("Great job!")
                        .font(.title)
                        .fontWeight(.semibold)
                    Text("You successfully completed the playground and learnt about pitch and rhythm!")
                        .lineLimit(nil)
                        .multilineTextAlignment(.center)
                    Spacer()
                        .frame(height: 20)
                    Text("I hope you enjoyed my playground and took something out of it. Please stay safe and enjoy your day :)")
                        .lineLimit(nil)
                        .multilineTextAlignment(.center)
                }.padding()
                Spacer()
            }
        }
    }
}
