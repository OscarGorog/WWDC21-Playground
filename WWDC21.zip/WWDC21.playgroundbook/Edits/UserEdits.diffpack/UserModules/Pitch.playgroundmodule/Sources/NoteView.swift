import SwiftUI

/// Displays a note name and toggles the background depending on whether the player got the note correct
public struct NoteView: View {
    
    public var noteViewHelper: NoteViewHelper
    
    public var body: some View {
        Text(noteViewHelper.note.rawValue)
            .foregroundColor(.black)
            .padding()
            .background(noteViewHelper.isCorrect ? Color.green.opacity(0.8) : Color.white.opacity(0.8))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}
