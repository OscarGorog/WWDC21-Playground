import ARKit
import UIKit
import Vision
import Combine

/// Handles displaying the live video feed and processing the current frame
public class VideoPreviewView: UIView {
    
    // MARK: - Variables
    public var solfaGameState: SolfaGame!
    private var videoLayer: AVCaptureVideoPreviewLayer! {
        guard let layer = layer as? AVCaptureVideoPreviewLayer else { fatalError("Could not get layer") }
        return layer
    }
    private var cameraProcessingQueue: DispatchQueue!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var solfaSignClassifierModel: VNCoreMLModel!
    private var classifySignRequest: VNCoreMLRequest!
    private var currentNoteHits = 0
    
    // MARK: - Initialisers
    init(solfaGameState: SolfaGame) {
        self.solfaGameState = solfaGameState
        super.init(frame: .zero)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override class var layerClass: AnyClass {
        // Override the default layer and set it to `AVCaptureVideoPreviewLayer`
        return AVCaptureVideoPreviewLayer.self
    }
    
    // MARK: - Functions
    
    /// Setup's the view
    private func setupView() {
        do {
            // Set the model
            let modelURL = try MLModel.compileModel(at: #fileLiteral(resourceName: "SolfaSignClassifier.mlmodel"))
            let mlModel = try MLModel(contentsOf: modelURL)
            solfaSignClassifierModel = try VNCoreMLModel(for: mlModel)
        } catch {
            solfaGameState.errorDescription = error.localizedDescription
        }
        
        // Create the `MLRequest`
        classifySignRequest = VNCoreMLRequest(model: solfaSignClassifierModel) { [weak self] (request, error) in
            guard let self = self else { return }
            if error != nil {
                self.solfaGameState.errorDescription = error!.localizedDescription
            } else {
                if let results = request.results as? [VNClassificationObservation],
                   let result = results.sorted(by: { $0.confidence > $1.confidence }).first,
                   let solfaNote = SolfaNote(rawValue: result.identifier) {
                    if self.solfaGameState.currentNote == solfaNote {
                        // Make sure we have at least ten hits of the note to be more accurate
                        self.currentNoteHits += 1
                        if self.currentNoteHits == 10 {
                            // If we hit ten hits, add ten points to the score and move to another note
                            self.currentNoteHits = 0
                            DispatchQueue.main.async {
                                self.solfaGameState.currentScore += 10
                                self.solfaGameState.currentNote = SolfaNote.randomElement()
                            }
                        }
                    }
                }
            }
        }
        
        // Set the camera processing queue
        cameraProcessingQueue = DispatchQueue(label: "com.Pitch.CameraProcessingQueue")
    }
    
    /// Start the camera
    public func startCamera() {
        // Set the video layer session if it does not exist
        if videoLayer.session == nil {
            videoLayer.videoGravity = .resizeAspectFill
            videoLayer.session = AVCaptureSession(bufferOutputDelegate: self, cameraProcessingQueue: cameraProcessingQueue)
            videoLayer.connection?.videoOrientation = .portrait
        }
        
        // Start running the session
        videoLayer.session?.startRunning()
    }
    
    /// Stop the camera
    public func stopCamera() {
        videoLayer.session?.stopRunning()
    }
}

extension VideoPreviewView: AVCaptureVideoDataOutputSampleBufferDelegate {
    // MARK: - Capture Video Data Output
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Get a `CVPixelBuffer` from a `CMSampleBuffer`
        guard let cvPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            solfaGameState.errorDescription = "Unable to get image from the sample buffer"
            return
        }
        
        do {
            // Perform the Vision request
            let handler = VNImageRequestHandler(cvPixelBuffer: cvPixelBuffer, options: [:])
            try handler.perform([classifySignRequest])
        } catch {
            solfaGameState.errorDescription = error.localizedDescription
        }
    }
}

