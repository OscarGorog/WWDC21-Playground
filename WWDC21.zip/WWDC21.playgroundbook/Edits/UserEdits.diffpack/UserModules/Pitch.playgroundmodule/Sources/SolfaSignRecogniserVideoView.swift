import SwiftUI

/// Allows the `VideoPreviewView` to be displayed in SwiftUI
public struct SolfaSignRecogniserVideoView: UIViewRepresentable {
    
    public let videoPreviewView: VideoPreviewView!
    
    public func makeUIView(context: Context) -> VideoPreviewView {
        return videoPreviewView
    }
    
    public func updateUIView(_ uiView: VideoPreviewView, context: Context) { }
}
