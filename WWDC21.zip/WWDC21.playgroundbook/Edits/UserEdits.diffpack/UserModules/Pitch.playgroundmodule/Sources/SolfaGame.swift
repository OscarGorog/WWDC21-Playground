import Combine
import Foundation

/// Manages the solfa game including the `VideoPreviewView`
public class SolfaGame: ObservableObject {
    
    // MARK: - Variables
    public var videoPreviewView: VideoPreviewView!
    private var gameTimer: AnyCancellable!
    private var isPaused = false
    @Published public var currentNote = SolfaNote.randomElement()
    @Published public var errorDescription: String? = nil
    @Published public var currentScore = 0
    @Published public var timeLeft = 30
    @Published public var isPlaying = false
    
    // MARK: - Initialisers
    init() {
        self.videoPreviewView = VideoPreviewView(solfaGameState: self)
    }
    
    // MARK: - Functions
    
    /// Starts the game
    public func startGame() {
        // Set the related variables
        isPlaying = true
        if !isPaused {
            currentNote = SolfaNote.randomElement()
            timeLeft = 30
            currentScore = 0
        }
        isPaused = false
        
        // Setup the game timer
        gameTimer = Timer.publish(every: 1, on: .main, in: .default)
            .autoconnect()
            .sink(receiveValue: { [self] (_) in
                timeLeft -= 1
                if timeLeft == 0 {
                    isPlaying = false
                    gameTimer.cancel()
                }
            })
        
        // Start the camera
        videoPreviewView.startCamera()
    }
    
    /// Pause the game
    public func pauseGame() {
        // Stop the camera and set other related variables
        videoPreviewView.stopCamera()
        isPaused = true
        gameTimer.cancel()
    }
}

