import SwiftUI
import SharedCode

/// Allows the user to select a song from the `Song` enum
public struct SelectSongView: View {
    
    public var dismissAction: (Song) -> Void
    @State private var alertIsPresented = false
    @State private var alertText = ""
    @State private var selectedSong: Song?
    
    public var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .edgesIgnoringSafeArea(.all)
            VStack {
                CustomNavigationBar(rightContent: {
                    Button(action: {
                        if let selectedSong = selectedSong {
                            dismissAction(selectedSong)
                        } else {
                            alertText = "Please select a song"
                            alertIsPresented = true
                        }
                    }, label: {
                        Text("Select")
                            .foregroundColor(selectedSong == nil ? .gray : .blue)
                            .fontWeight(.semibold)
                    })
                })
                Spacer()
                VStack {
                    Image(systemName: "pianokeys")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 100)
                        .foregroundColor(.blue)
                    Text("Select a song")
                        .font(.title)
                        .fontWeight(.semibold)
                }.padding()
                Spacer()
                VStack {
                    ForEach(Song.allCases, id: \.self) { (song) in
                        Button(action: {
                            selectedSong = song
                        }, label: {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(song.rawValue)
                                        .font(.headline)
                                    Text("\(song.notes.count) notes")
                                        .font(.subheadline)
                                }
                                Spacer()
                            }.padding()
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)
                            .background(selectedSong == song ? Color.blue : Color.blue.opacity(0.5))
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        })
                    }
                }.padding()
                Spacer()
            }
        }.alert(isPresented: $alertIsPresented) {
            Alert(title: Text(alertText))
        }
    }
}
