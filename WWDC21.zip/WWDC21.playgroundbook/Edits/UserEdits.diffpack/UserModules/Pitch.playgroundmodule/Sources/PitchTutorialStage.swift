import Foundation
import SharedCode

/// An enum describing all the stages of the tutorial
public enum PitchTutorialStage: Int, CaseIterable, TutorialStage {
    case settingUp = 0
    case pianoNotesIntroduction
    case westernSystem
    case notes
    case keysOnAPiano
    case playTheSongGameIntroduction
    case playTheSongGame
    case songGameFinished
    case solfaNotesIntroduction
    case explainMoveToSolfaStage
    case animateMoveToSolfaStage
    case setupSolfaImage
    case solfaImageIsSetup
    case solfaHandSignsBackground
    case actualHandSigns
    case explainSolfaSignsGame
    case explainSolfaSignsGameOrientation
    case solfaGame
    
    /// A explanation of the current stage
    public var explanation: String {
        switch self {
        case .settingUp:
            return "Let's get setup!"
        case .pianoNotesIntroduction:
            return "Welcome! Ready to learn about pitch? As you can see in front of you we're going to use a piano to demonstrate how pitch is used. Throughout the introduction you can hit any key to hear it! Hit next when you'r ready to continue!"
        case .westernSystem:
            return "Western music is the most widely used music system used throughout the world and it is based around 12 different notes."
        case .notes:
            return "The notes in the Western system are: C, C#, D, D#, E, F, G, G#, A, A#, B. A sharp is a note one semitone higher then the previous one (C -> C#)"
        case .keysOnAPiano:
            return "A standard piano consists of 88 keys (52 white and 36 black) and 7 octaves. In the example below we have 1 octave, ranging from Low-C to High-C"
        case .playTheSongGameIntroduction:
            return "Now let's play a game! In this game you will choose a song a list of notes will show up for that song. You will then need to play that song, it's easy as that! :)"
        case .playTheSongGame:
            return ""
        case .songGameFinished:
            return "Well done, you'r playing was amazing! Now move on to learn about the Solfa system."
        case .solfaNotesIntroduction:
            return "The Solfa system is a system that tries to make it easier to learn and read music, mainly focusing on the white notes. Each white note is represented by a different name and a hand sign. For example the note C is denoted by the name `Do` and a fist."
        case .explainMoveToSolfaStage:
            return PitchTutorialStage.animateMoveToSolfaStage.explanation.appending(" (hit next)")
        case .animateMoveToSolfaStage:
            return "For now, let's get rid of the sharps (black notes) and the High-C and add in the Solfa names"
        case .setupSolfaImage:
            return "Let's also setup the Solfa signs image!"
        case .solfaImageIsSetup:
            return "Perfect, great job! Now, on the Piano you can see the Solfa names and you should also be able to see the image of the Solfa hand signs you just placed."
        case .solfaHandSignsBackground:
            return "The Solfa system was invented by Sarah Ann Glover in 1812 and popularised by John Curwen. The idea of the Solfa system is to make it easier to teach aural skills and sight-reading. Originally, the first name of the first note (Do) was named Ut!"
        case .actualHandSigns:
            return "So, as you can see on the image each hand sign has a name and if you look at the piano you can see that, the name matches up with a note. This is how the notes are represented! Take a minute to explore the hand signs and the piano and then hit next to continue."
        case .explainSolfaSignsGame:
            return "Now that you've learnt a bit about the Solfa system let's play a game! In this game you will be given a note, and will need to hold up the hand sign for that given note. Every sign you get correct you score 10 points and you have 30 seconds to get the highest score you can!"
        case .explainSolfaSignsGameOrientation:
            return "Please switch you'r device for portrait for this game. This is because there is an orientation bug that returns the wrong value in Swift Playgrounds. Enjoy the game!"
        case .solfaGame:
            return ""
        }
    }
    
    /// At certain points we need to block going back, for example during the introduction because we cannot redo the setting up stage
    public var canGoBack: Bool {
        switch self {
        case .pianoNotesIntroduction, .playTheSongGame, .songGameFinished, .solfaNotesIntroduction, .animateMoveToSolfaStage, .setupSolfaImage, .solfaImageIsSetup, .solfaGame:
            return false
        default:
            return true
        }
    }
    
    /// At certain points we need to block going forward, for example when we are animating the piano. The `PitchTeacherView` will manage activating the button once the animation is complete.
    public var canGoForward: Bool {
        switch self {
        case .playTheSongGame, .animateMoveToSolfaStage, .setupSolfaImage:
            return false
        default:
            return true
        }
    }
}
