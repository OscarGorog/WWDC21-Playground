import ARKit

/// Gives a description of the current camera tracking state or `nil` if it is normal
public extension ARCamera.TrackingState {
    var description: String? {
        switch self {
        case .notAvailable:
            return "AR is unavailable. Please try restarting the playground"
        case .limited(let limitedReason):
            switch limitedReason {
            case .initializing:
                return "Getting the camera ready"
            case .excessiveMotion:
                return "Please hold the iPad still"
            case .insufficientFeatures:
                return "Try moving to a lighter area"
            case .relocalizing:
                return "Try moving to a lighter area or restart the playground"
            @unknown default:
                return "Try restarting the playground"
            }
        case .normal:
            return nil
        }
    }
}
