import ARKit
import RealityKit

/// Manages the state of the `ARView` and all of it's objects including the `ARCoachingOverlayView`
public class ARViewState: NSObject, ObservableObject {
    
    // MARK: - Variables
    public var arView = ARView(frame: .zero, cameraMode: .ar)
    public var pianoScene: Piano.Scene!
    private var coachingOverlayView: ARCoachingOverlayView!
    @Published public var isSettingUpScene = true
    @Published public var arStatusDescription: String? = nil
    
    // MARK: - Initialisers
    override init() {
        super.init()
        setupViews()
    }
    
    // MARK: - Functions
    
    /// Setup the necessary views
    private func setupViews() {
        // Set the `ARView` delegate
        arView.session.delegate = self
        
        // Set the content scale factor because Swift Playgrounds has memory limitations
        arView.contentScaleFactor = 0.75
        
        // Create and add the coaching view
        coachingOverlayView = ARCoachingOverlayView()
        coachingOverlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        coachingOverlayView.delegate = self
        arView.addSubview(coachingOverlayView)
    }
    
    /// Setup the coaching view with the specified goal
    public func setupCoachingView(with goal: ARCoachingOverlayView.Goal) {
        // Setup the coaching view
        coachingOverlayView.session = arView.session
        coachingOverlayView.goal = goal
        coachingOverlayView.activatesAutomatically = true
        coachingOverlayView.setActive(true, animated: true)
        
        // Create an `ARConfiguration` with the plane depending on the coaching view goal
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = goal == .horizontalPlane ? .horizontal : .vertical
        if ARWorldTrackingConfiguration.supportsFrameSemantics(.personSegmentationWithDepth) {
            configuration.frameSemantics.insert(.personSegmentationWithDepth)
        }
        
        // Run the configuration
        arView.session.run(configuration)
    }
    
    /// Disable's the coaching view
    public func disableCoachingView() {
        coachingOverlayView.setActive(false, animated: true)
        coachingOverlayView.activatesAutomatically = false
        isSettingUpScene = false
    }
}

extension ARViewState: ARCoachingOverlayViewDelegate {
    // MARK: - Coaching Overlay
    public func coachingOverlayViewDidDeactivate(_ coachingOverlayView: ARCoachingOverlayView) {
        coachingOverlayView.activatesAutomatically = false
        
        // Depending on the coaching goal, either add the Piano or the Solfa hand signs image
        if coachingOverlayView.goal == .horizontalPlane {
            pianoScene = try! Piano.loadScene()
            arView.scene.anchors.append(pianoScene)
            
            isSettingUpScene = false
        } else {
            var material = SimpleMaterial()
            do {
                material.baseColor = try .texture(.load(contentsOf: #fileLiteral(resourceName: "Solfa Hand Signs.png")))
                
                let mesh = MeshResource.generatePlane(width: 0.75, depth: 0.5, cornerRadius: 0.05)
                let component = ModelComponent(mesh: mesh, materials: [material])
                
                let parentEntity = ModelEntity()
                parentEntity.components.set(component)
                parentEntity.generateCollisionShapes(recursive: true)
                arView.installGestures(.all, for: parentEntity)
                
                let anchor = AnchorEntity(.plane(.vertical, classification: .wall, minimumBounds: .zero))
                anchor.addChild(parentEntity)
                
                arView.scene.addAnchor(anchor)
                
                isSettingUpScene = false
            } catch {
                arStatusDescription = error.localizedDescription
            }
        }
    }
}

extension ARViewState: ARSessionDelegate {
    // MARK: - Session Tracking
    public func session(_ session: ARSession, didFailWithError error: Error) {
        arStatusDescription = error.localizedDescription
    }
    
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        arStatusDescription = camera.trackingState.description
    }
}
