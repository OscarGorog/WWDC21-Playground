import Foundation

/// All the notes in the Western music system
public enum Note: String {
    case lowC = "Low C"
    case cSharp = "C Sharp"
    case d = "D"
    case dSharp = "D Sharp"
    case e = "E"
    case f = "F"
    case fSharp = "F Sharp"
    case g = "G"
    case gSharp = "G Sharp"
    case a = "A"
    case aSharp = "A Sharp"
    case b = "B"
    case highC = "High C"
}
