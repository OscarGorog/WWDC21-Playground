import Foundation
import SharedCode

/// An enum that has all the songs along with the notes
public enum Song: String, CaseIterable {
    case twinkleTwinkleLittleStar = "Twinkle Twinkle Little Star"
    case maryHadALittleLamb = "Mary Had a Little Lamb"
    
    /// The notes in the song
    public var notes: [Note] {
        switch self {
        case .twinkleTwinkleLittleStar:
            let introduction: [Note] = [.lowC, .lowC, .g, .g, .a, .a, .g, .f, .f, .e, .e, .d, .d, .lowC]
            let goingDownNotes: [Note] = [.g, .g, .f, .f, .e, .e, .d]
            return introduction + goingDownNotes + goingDownNotes + introduction
        case .maryHadALittleLamb:
            let introduction: [Note] = [.e, .d, .lowC, .d, .e, .e, .e,]
            return introduction + [.d, .d, .d, .e, .g, .g] + introduction.appending([.e, .d, .d, .e, .d, .lowC])
        }
    }
}
