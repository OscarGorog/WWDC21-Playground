import ARKit

/// Allows a `AVCaptureSession` to be conveniently initialised by adding the necessary inputs and outputs
public extension AVCaptureSession {
    convenience init(bufferOutputDelegate: AVCaptureVideoDataOutputSampleBufferDelegate, cameraProcessingQueue: DispatchQueue) {
        self.init()
        
        // Create a video device input and make sure we can add it
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
              let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice),
              canAddInput(videoDeviceInput) else { return }
        addInput(videoDeviceInput)
        
        // Create a video data output and make sure we can add it
        let videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.setSampleBufferDelegate(bufferOutputDelegate, queue: cameraProcessingQueue)
        guard canAddOutput(videoDataOutput) else { return }
        addOutput(videoDataOutput)
    }
}
