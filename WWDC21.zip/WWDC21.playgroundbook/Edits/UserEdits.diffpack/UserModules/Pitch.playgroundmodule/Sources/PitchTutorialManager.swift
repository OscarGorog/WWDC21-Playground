import Foundation
import SharedCode

/// Manages the tutorial based of the `PitchTutorialManager` enum
public class PitchTutorialManager: TutorialManager {
    @Published public var currentStage: PitchTutorialStage = .settingUp
}
