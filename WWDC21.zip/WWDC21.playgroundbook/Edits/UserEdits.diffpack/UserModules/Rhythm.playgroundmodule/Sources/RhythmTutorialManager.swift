import Foundation
import SharedCode

/// Manages the tutorial based of the `RhythmTutorialManager` enum
public class RhythmTutorialManager: TutorialManager {
    @Published public var currentStage: RhythmTutorialStage = .welcomeToThePlayground
}
