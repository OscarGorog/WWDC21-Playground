import Foundation

/// The types of success that can occur when validating a rhythm
public enum RhythmSuccess {
    case nextStage
    case finishedStages
}

