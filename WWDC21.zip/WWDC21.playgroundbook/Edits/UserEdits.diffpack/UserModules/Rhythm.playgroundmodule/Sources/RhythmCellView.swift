import SwiftUI

/// The cell view for a rhythm
public struct RhythmCellView: View {
    
    @ObservedObject public var rhythmTutorialManager: RhythmTutorialManager
    public var rhythm: Rhythm!
    
    public var body: some View {
        VStack {
                Image(uiImage: #imageLiteral(resourceName: "\(rhythm.rawValue).png"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            Text(rhythm.rawValue)
                .font(.headline)
        }
        .padding()
        .frame(height: 100)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .if(rhythmTutorialManager.currentStage == .rhythmGame, transform: { (vStack) in
            vStack.onDrag {
                return NSItemProvider(object: rhythm.rawValue as NSString)
            }
        })
    }
}
