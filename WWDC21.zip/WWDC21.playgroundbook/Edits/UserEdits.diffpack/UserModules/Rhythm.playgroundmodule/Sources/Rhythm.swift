import UIKit

/// An enum with all the available rhythms
public enum Rhythm: String, CaseIterable {
    case rest = "Rest"
    case crotchet = "Crotchet"
    case twoQuavers = "Two Quavers"
    case fourSemiquavers = "Four Semiquavers"
    
    public var image: UIImage? {
        let url = URL(fileReferenceLiteralResourceName: "\(self.rawValue).png")
        
        do {
            let urlData = try Data(contentsOf: url)
            return UIImage(data: urlData)
        } catch {
            print(error)
            return nil
        }
    }
}
