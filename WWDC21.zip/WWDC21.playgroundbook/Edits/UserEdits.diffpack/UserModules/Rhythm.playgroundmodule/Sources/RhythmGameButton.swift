import SwiftUI

/// A button used for the rhythm game to either play/pause or validate the inputted rhythm
public struct RhythmGameButton: View {
    
    public enum RhythmGameButtonType {
        case playPause
        case validateRhythm
    }
    public var buttonType: RhythmGameButtonType
    @ObservedObject public var rhythmGenerator: RhythmGenerator
    public var buttonAction: () -> Void
    
    public var body: some View {
        Button(action: buttonAction) {
            VStack {
                Image(systemName: buttonType == .playPause ? (rhythmGenerator.isPlaying ? "pause.circle" : "play.circle") : "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 100)
                Text(buttonType == .playPause ? (rhythmGenerator.isPlaying ? "Playing..." : "Hear Rhythm") : "Check Order")
                    .font(.largeTitle)
                    .lineLimit(nil)
                    .multilineTextAlignment(.center)
            }
        }
        .disabled(rhythmGenerator.isPlaying)
        .padding(.vertical)
        .padding(.horizontal, 50)
    }
}
