import Combine
import AVFoundation
/// Manages generating the rhythm for the rhythm game and playing the rhythm
public class RhythmGenerator: ObservableObject, MetronomeDelegate {
    
    // MARK: - Variables
    private struct AudioPlayers {
        var crotchetPlayer: AVAudioPlayer?
        var twoQuaversPlayer: AVAudioPlayer?
        var fourSemiquaversPlayer: AVAudioPlayer?
    }
    private var audioPlayers = AudioPlayers()
    private var metronome = Metronome()
    public var rhythms: [Rhythm]!
    @Published public var currentRhythm = 0
    @Published public var isPlaying = false
    
    // MARK: - Initialisers
    public init() {
        setupAudio()
        createNewRhythm()
    }
    
    // MARK: - Functions
    private func setupAudio() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            audioPlayers.crotchetPlayer = try AVAudioPlayer(contentsOf: #fileLiteral(resourceName: "Crotchet.mp3"))
            audioPlayers.twoQuaversPlayer = try AVAudioPlayer(contentsOf: #fileLiteral(resourceName: "Two Quavers.mp3"))
            audioPlayers.fourSemiquaversPlayer = try AVAudioPlayer(contentsOf: #fileLiteral(resourceName: "Four Semiquavers.mp3"))
            
            audioPlayers.crotchetPlayer?.prepareToPlay()
            audioPlayers.twoQuaversPlayer?.prepareToPlay()
            audioPlayers.fourSemiquaversPlayer?.prepareToPlay()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    public func playRhythm() {
        guard !isPlaying else { return }
        isPlaying = true
        metronome.delegate = self
        metronome.play(shouldPlaySounds: false)
    }
    
    public func createNewRhythm() {
        rhythms = Rhythm.allCases.shuffled()
    }
    
    public func metronomeDidFire() {
        if let rhythm = rhythms[safeIndex: currentRhythm] {
            switch rhythm {
            case .rest:
                break
            case .crotchet:
                audioPlayers.crotchetPlayer?.play()
            case .twoQuavers:
                audioPlayers.twoQuaversPlayer?.play()
            case .fourSemiquavers:
                audioPlayers.fourSemiquaversPlayer?.play()
            }
            currentRhythm += 1
        } else {
            currentRhythm = 0
            isPlaying = false
            metronome.pause()
        }
    }
}
