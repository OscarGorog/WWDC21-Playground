import UIKit

/// Contains the data that the `OverheadDisplayView` uses
public struct OverheadDisplayInformation {
    public var systemImageName: String
    public var imageColor: UIColor
    public var title: String
    public var description: String
}
