import SwiftUI

/// The button used to get a hint for the rhythm game
public struct HintButton: View {
    
    @ObservedObject public var rhythmGenerator: RhythmGenerator
    public var buttonAction: () -> Void
    
    public var body: some View {
        Button(action: buttonAction) {
            Text("Need a hint?")
                .font(.title)
        }.disabled(rhythmGenerator.isPlaying)
    }
}
