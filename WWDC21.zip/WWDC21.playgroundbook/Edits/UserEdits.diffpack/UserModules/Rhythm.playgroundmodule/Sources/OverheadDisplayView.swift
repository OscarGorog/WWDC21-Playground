import SwiftUI

/// A view that displays a small piece of information to the user
public struct OverheadDisplayView: View {
    
    public var displayInformation: OverheadDisplayInformation
    
    public var body: some View {
        HStack(spacing: 14) {
            Image(systemName: displayInformation.systemImageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 20)
                .foregroundColor(Color(displayInformation.imageColor))
            VStack(alignment: .leading) {
                Text(displayInformation.title)
                    .font(.headline)
                Text(displayInformation.description)
                    .font(.subheadline)
                    .foregroundColor(Color.primary.opacity(0.6))
            }
        }
        .padding(.horizontal, 12)
        .padding(14)
        .background(
            Capsule()
                .foregroundColor(.white)
                .shadow(color: Color.black.opacity(0.20), radius: 20)
        )
    }
}

/// Allows the `OverheadDisplayView` to be easily presented
public extension View {
    func overheadDisplay(isShown: Binding<Bool>, content: () -> OverheadDisplayView) -> some View {
        ZStack(alignment: .top) {
            self
            
            if isShown.wrappedValue {
                content()
                    .padding(.top)
                    .transition(AnyTransition.move(edge: .top).combined(with: .opacity))
                    .zIndex(1)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                isShown.wrappedValue = false
                            }
                        }
                    }
            }
        }
    }
}
