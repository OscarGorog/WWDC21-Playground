import SwiftUI

/// A custom slider that controls the metronome's speed
public struct MetronomeSlider: View {
    
    @Binding public var beatsPerMinute: Int
    @State private var height: CGFloat = 60
    @State private var dragPreviousHeight: CGFloat = 60
    
    public var body: some View {
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .frame(width: 80, height: 260)
                .foregroundColor(Color(.systemGray4))
            
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .frame(width: 80, height: height)
                .foregroundColor(height < 6 ? .clear : .blue)
                .overlay(
                    Circle()
                        .fill(Color.white)
                        .frame(width: 30, height: 30)
                        .offset(y: -height / 2)
                        .shadow(radius: 10)
                )
        }
        .gesture(
            DragGesture()
                .onChanged { (gestureValue) in
                    let newHeight = dragPreviousHeight - gestureValue.translation.height
                    if newHeight > 1 && newHeight < 261 {
                        height = newHeight
                        beatsPerMinute = Int(height)
                    }
                }
                .onEnded { (_) in
                    dragPreviousHeight = height
                }
        )
        .onAppear {
            beatsPerMinute = 60
            height = 60
            dragPreviousHeight = 60
        }
        .padding(.vertical)
        .padding(.horizontal, 50)
    }
}
