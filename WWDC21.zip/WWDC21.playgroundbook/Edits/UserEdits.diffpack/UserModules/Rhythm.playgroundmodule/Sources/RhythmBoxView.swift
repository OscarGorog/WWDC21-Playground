import SwiftUI
import UniformTypeIdentifiers

/// Displays the box number or a rhythm when a user drags one in
public struct RhythmBoxView: View {
    
    public var boxNumber: Int
    @Binding public var rhythm: Rhythm?
    @ObservedObject public var rhythmGenerator: RhythmGenerator
    @ObservedObject public var metronome: Metronome
    @State private var isHoveringOverView = false
    
    public var body: some View {
        Button(action: {}) {
            VStack {
                if let rhythm = rhythm {
                    Image(uiImage: #imageLiteral(resourceName: "\(rhythm.rawValue).png").withColor(isHoveringOverView || rhythmGenerator.currentRhythm == boxNumber || (metronome.isPlaying && metronome.currentBeat == boxNumber) ? Color.blue : Color.gray))
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 100)
                }
                Text(rhythm?.rawValue ?? String(boxNumber))
                    .font(.title)
                    .lineLimit(nil)
                    .multilineTextAlignment(.center)
                if rhythmGenerator.isPlaying && rhythm != nil {
                    Text(String(boxNumber))
                        .font(.title2)
                }
            }
            .foregroundColor(isHoveringOverView || rhythmGenerator.currentRhythm == boxNumber || (metronome.isPlaying && metronome.currentBeat == boxNumber) ? .blue : .gray)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                Group {
                    if isHoveringOverView || rhythmGenerator.currentRhythm == boxNumber || (metronome.isPlaying && metronome.currentBeat == boxNumber) {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .foregroundColor(Color.blue.opacity(0.3))
                    }
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(isHoveringOverView || rhythmGenerator.currentRhythm == boxNumber || (metronome.isPlaying && metronome.currentBeat == boxNumber) ? Color.blue : Color.gray)
            )
            
        }
        .disabled(true)
        .onDrop(of: [.plainText], isTargeted: $isHoveringOverView) { (itemProviders) in // Seems like `onDrop` is only called when the parent view is a button so we have to embed the `VStack` in a `Button`
            if let item = itemProviders.first {
                item.loadItem(forTypeIdentifier: UTType.plainText.identifier, options: [:]) { (stringData, error) in
                    if error != nil {
                        print(error!)
                    } else {
                        guard let data = stringData as? Data,
                              let string = String(data: data, encoding: .utf8),
                              let rhythm = Rhythm(rawValue: string) else { return }
                        DispatchQueue.main.async {
                            self.rhythm = rhythm
                        }
                    }
                }
                
                return true
            } else {
                return false
            }
        }
    }
}
