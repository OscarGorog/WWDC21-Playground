import Combine
import Foundation
import AVFoundation

/// Manages the metronome optionally including playing the ticks
public class Metronome: ObservableObject {
    
    // MARK: - Variables
    public var delegate: MetronomeDelegate?
    private var timer: AnyCancellable?
    private var soundPlayer: AVAudioPlayer!
    private var accentPlayer: AVAudioPlayer!
    @Published public var isPlaying = false
    @Published public var currentBeat: Int!
    private var tempo: Int!
    
    // MARK: - Initialisers
    public init(tempo: Int = 60) {
        self.tempo = tempo
        self.currentBeat = 0
        
        setupAudio()
    }
    
    // MARK: - Functions
    private func setupAudio() {
        guard let metronomeAccentURL = Bundle.main.url(forResource: "Metronome Accent", withExtension: "wav"),
              let metronomeSoundURL = Bundle.main.url(forResource: "Metronome Sound", withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            accentPlayer = try AVAudioPlayer(contentsOf: metronomeAccentURL)
            soundPlayer = try AVAudioPlayer(contentsOf: metronomeSoundURL)
            
            accentPlayer.prepareToPlay()
            soundPlayer.prepareToPlay()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    public func play(shouldPlaySounds: Bool) {
        isPlaying = true
        
        delegate?.metronomeDidFire()
        if shouldPlaySounds {
            playSound()
        }
        timer = Timer.publish(every: TimeInterval(60 / Double(tempo)), on: .main, in: .common)
            .autoconnect()
            .sink(receiveValue: { [self] (_) in
                delegate?.metronomeDidFire()
                if shouldPlaySounds {
                    playSound()
                }
            })
    }
    
    private func playSound() {
        if currentBeat == 4 {
            currentBeat = 0
        }
        if currentBeat == 0 {
            accentPlayer.play()
        } else {
            soundPlayer.play()
        }
        currentBeat += 1
    }
    
    public func pause() {
        isPlaying = false
        timer?.cancel()
    }
    
    public func changeTempo(to newTempo: Int) {
        isPlaying = false
        timer?.cancel()
        tempo = newTempo
        currentBeat = 0
    }
}
