import SwiftUI
import SharedCode

/// Manages everything the user sees
public struct RhythmView: View {
    
    @ObservedObject public var gameState = RhythmGameState()
    @ObservedObject public var rhythmTutorialManager = RhythmTutorialManager()
    private var metronome = Metronome()
    @State private var sliderBeatsPerMinute = 60
    @State private var overheadDisplayIsShown = false
    @State private var overheadDisplayInformation: OverheadDisplayInformation!
    @State private var explanationText = ""
    @State private var canGoBack = false
    @State private var canGoForward = true
    @State private var isRhythmPartFinishedViewPresented = false
    
    public init() { }
    
    public var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .edgesIgnoringSafeArea(.all)
            VStack {
                VStack {
                    textView
                    Spacer()
                    boxAndButtonsView
                    Spacer()
                    rhythmsAndControlStateButtonsView
                }
            }.padding()
        }
        .onReceive(rhythmTutorialManager.$currentStage) { (currentStage) in
            explanationText = currentStage.explanation
            canGoBack = rhythmTutorialManager.canGoBack()
            canGoForward = rhythmTutorialManager.canGoForward()
            
            if currentStage == .whatIsAMetronome || currentStage == .explainRhythmGame {
                // Reset the tempo before in case the user goes back
                // Reset the tempo after showing the metronome in preparation for the rhythm game
                metronome.changeTempo(to: 60)
            }
        }
        .onChange(of: sliderBeatsPerMinute) { (bpm) in
            metronome.changeTempo(to: Int(bpm))
        }
        .sheet(isPresented: $isRhythmPartFinishedViewPresented) {
            FinishedRhythmPageView(playAgainBlock: {
                gameState.resetGame()
                isRhythmPartFinishedViewPresented = false
            })
        }
        .overheadDisplay(isShown: $overheadDisplayIsShown) {
            OverheadDisplayView(displayInformation: overheadDisplayInformation)
        }
    }
    
    var textView: some View {
        Group {
            if rhythmTutorialManager.currentStage == .rhythmGame {
                VStack(spacing: 0) {
                    Text("Place the rhythms below in the boxes in the correct order")
                        .font(.title)
                        .fontWeight(.semibold)
                        .lineLimit(nil)
                        .multilineTextAlignment(.center)
                    Text("\(gameState.currentStage) of \(gameState.numberOfStages)")
                        .font(.title3)
                }
            } else {
                ExplanationView(title: $explanationText, subtitle: .constant(nil))
            }
        }
    }
    
    var boxAndButtonsView: some View {
        HStack {
            if rhythmTutorialManager.currentStage == .rhythmGame {
                Spacer()
                RhythmGameButton(buttonType: .playPause, rhythmGenerator: gameState.rhythmGenerator) {
                    gameState.rhythmGenerator.playRhythm()
                }
                Spacer()
            } else if rhythmTutorialManager.currentStage == .useAMetronome {
                Spacer()
                PlayStopMetronomeButton(metronome: metronome)
                Spacer()
            }
            VStack(spacing: 8) {
                HStack(spacing: 8) {
                    RhythmBoxView(boxNumber: 1, rhythm: $gameState.firstRhythm, rhythmGenerator: gameState.rhythmGenerator, metronome: metronome)
                    RhythmBoxView(boxNumber: 2, rhythm: $gameState.secondRhythm, rhythmGenerator: gameState.rhythmGenerator, metronome: metronome)
                }
                HStack(spacing: 8) {
                    RhythmBoxView(boxNumber: 3, rhythm: $gameState.thirdRhythm, rhythmGenerator: gameState.rhythmGenerator, metronome: metronome)
                    RhythmBoxView(boxNumber: 4, rhythm: $gameState.fourthRhythm, rhythmGenerator: gameState.rhythmGenerator, metronome: metronome)
                }
            }
            if rhythmTutorialManager.currentStage == .rhythmGame {
                Spacer()
                VStack(spacing: 0) {
                    RhythmGameButton(buttonType: .validateRhythm, rhythmGenerator: gameState.rhythmGenerator) {
                        gameState.checkGuess { (result) in
                            switch result {
                            case .failure(let error):
                                switch error {
                                case .unattemptedBeats:
                                    overheadDisplayInformation = OverheadDisplayInformation(systemImageName: "xmark", imageColor: .systemRed, title: "Unattempted Beats", description: "Please fill in all the blocks")
                                case .incorrectRhythm:
                                    overheadDisplayInformation = OverheadDisplayInformation(systemImageName: "xmark", imageColor: .systemRed, title: "Incorrect Rhythm", description: ["You can do it!", "Keep going!", "I believe in you!"].randomElement()!)
                                }
                                
                                withAnimation {
                                    overheadDisplayIsShown = true
                                }
                            case .success(let success):
                                switch success {
                                case .nextStage:
                                    overheadDisplayInformation = OverheadDisplayInformation(systemImageName: "checkmark", imageColor: .systemGreen, title: "Correct!", description: ["Great job!", "Only \(gameState.numberOfStages - (gameState.currentStage - 1)) more!"].randomElement()!)
                                    withAnimation {
                                        overheadDisplayIsShown = true
                                    }
                                case .finishedStages:
                                    isRhythmPartFinishedViewPresented = true
                                }
                            }
                        }
                    }
                    HintButton(rhythmGenerator: gameState.rhythmGenerator) {
                        if let hint = gameState.getHint() {
                            overheadDisplayInformation = OverheadDisplayInformation(systemImageName: "questionmark", imageColor: .systemBlue, title: "Hint", description: hint)
                        } else {
                            overheadDisplayInformation = OverheadDisplayInformation(systemImageName: "questionmark", imageColor: .systemBlue, title: "Hint", description: "No more hints available")
                        }
                        withAnimation {
                            overheadDisplayIsShown = true
                        }
                    }
                }
                Spacer()
            } else if rhythmTutorialManager.currentStage == .useAMetronome {
                Spacer()
                VStack {
                    MetronomeSlider(beatsPerMinute: $sliderBeatsPerMinute)
                    Text("\(sliderBeatsPerMinute) BPM")
                        .font(.title)
                        .fontWeight(.semibold)
                }
                Spacer()
            }
        }
    }
    
    var rhythmsAndControlStateButtonsView: some View {
        HStack(alignment: .bottom) {
            if rhythmTutorialManager.currentStage != .rhythmGame {
                ControlStateButton(buttonType: .goBack,
                                   isEnabled: $canGoBack,
                                   tutorialManager: rhythmTutorialManager)
                Spacer()
            }
            VStack(spacing: 10) {
                HStack {
                    ForEach(Rhythm.allCases, id: \.self) { (rhythm) in
                        RhythmCellView(rhythmTutorialManager: rhythmTutorialManager, rhythm: rhythm)
                    }
                }
                if rhythmTutorialManager.currentStage == .rhythmGame {
                    Text("(You can now drag these into the boxes)")
                }
            }
            .padding()
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(radius: 20)
            if rhythmTutorialManager.currentStage != .rhythmGame {
                Spacer()
                ControlStateButton(buttonType: .next,
                                   isEnabled: $canGoForward,
                                   tutorialManager: rhythmTutorialManager)
            }
        }
        .environmentObject(rhythmTutorialManager)
    }
}
