import SwiftUI

/// A button that manages playing and stopping a metronome
public struct PlayStopMetronomeButton: View {
    
    @ObservedObject var metronome: Metronome
    
    public var body: some View {
        Button(action: {
            if metronome.isPlaying {
                metronome.pause()
            } else {
                metronome.play(shouldPlaySounds: true)
            }
        }) {
            VStack {
                Image(systemName: metronome.isPlaying ? "pause.circle" : "play.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 100)
                Text(metronome.isPlaying ? "Stop" : "Play")
                    .font(.largeTitle)
                    .lineLimit(nil)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.vertical)
        .padding(.horizontal, 50)
    }
}
