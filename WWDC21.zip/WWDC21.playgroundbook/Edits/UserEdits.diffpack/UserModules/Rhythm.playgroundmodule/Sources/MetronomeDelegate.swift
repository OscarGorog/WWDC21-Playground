import Foundation

/// The metronome delegate
public protocol MetronomeDelegate {
    func metronomeDidFire()
}
