import Foundation

/// An error that can occur when validating a rhythm
public enum RhythmError: Error {
    case unattemptedBeats
    case incorrectRhythm
}
