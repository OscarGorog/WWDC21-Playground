import Foundation
import SharedCode

/// An enum describing all the stages of the tutorial
public enum RhythmTutorialStage: Int, CaseIterable, TutorialStage {
    case welcomeToThePlayground
    case basicRhythmElements
    case whatIsAMetronome
    case useAMetronome
    case explainRhythmGame
    case rhythmGame
    
    /// A explanation of the current stage
    public var explanation: String {
        switch self {
        case .welcomeToThePlayground:
            return "Welcome to my playground! This playground will help teach you two fundamental parts of music theory: rhythm and pitch. I hope you learn something new!"
        case .basicRhythmElements:
            return "The four most basic rhythms are a rest, crotchet, quaver and semiquaver. A rest and a crotchet last for one beat. A quaver lasts for half a beat and a semiquaver lasts for a quarter beat."
        case .whatIsAMetronome:
            return "A metronome is used to help stay in time while playing an instrument. You specify the Beats Per Minute (BPM), and the metronome plays a tick for each beat. At 60 BPM, the metronome will play one beat per second."
        case .useAMetronome:
            return "Each square below represents a beat. You can adjust the BPM of the metronome using the slider. You can explore the metronome below."
        case .explainRhythmGame:
            return "Now let's play a game! You will hear a rhythm and be able to see what beats they land on. The game is to select the correct rhythm and drag it to the corresponding box. Hit next to play!"
        case .rhythmGame:
            return ""
        }
    }
    
    /// We never need to block going back so we can always return true. See `PitchTutorialStage` for an example of when we do need to block going back
    public var canGoBack: Bool {
        return true
    }
    
    /// We never need to block going forward so we can always return true. See `PitchTutorialStage` for an example of when we do need to block going forward
    public var canGoForward: Bool {
        return true
    }
}
