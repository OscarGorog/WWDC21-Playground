import Foundation

/// Manages the rhythm game state
public class RhythmGameState: ObservableObject {
    
    // MARK: - Variables
    @Published public var firstRhythm: Rhythm?
    @Published public var secondRhythm: Rhythm?
    @Published public var thirdRhythm: Rhythm?
    @Published public var fourthRhythm: Rhythm?
    @Published public var currentStage = 1
    public var hintsUsed = 0
    public var numberOfStages = 3
    public var rhythmGenerator = RhythmGenerator()
    
    // MARK: - Functions
    public func playRhythm() {
        rhythmGenerator.playRhythm()
    }
    
    public func checkGuess(completionHandler: (Result<RhythmSuccess, RhythmError>) -> Void) {
        // Make sure the user has dragged in rhythms into every box
        guard let firstRhythm = firstRhythm,
              let secondRhythm = secondRhythm,
              let thirdRhythm = thirdRhythm,
              let fourthRhythm = fourthRhythm else {
            completionHandler(.failure(.unattemptedBeats))
            return
        }
        
        // Check the rhythms
        if rhythmGenerator.rhythms == [firstRhythm, secondRhythm, thirdRhythm, fourthRhythm] {
            if currentStage == numberOfStages {
                completionHandler(.success(.finishedStages))
            } else {
                currentStage += 1
                hintsUsed = 0
                rhythmGenerator.createNewRhythm()
                self.firstRhythm = nil
                self.secondRhythm = nil
                self.thirdRhythm = nil
                self.fourthRhythm = nil
                completionHandler(.success(.nextStage))
            }
        } else {
            completionHandler(.failure(.incorrectRhythm))
        }
    }
    
    public func resetGame() {
        // Reset the game by setting all related variables
        currentStage = 1
        hintsUsed = 0
        rhythmGenerator.createNewRhythm()
        firstRhythm = nil
        secondRhythm = nil
        thirdRhythm = nil
        fourthRhythm = nil
    }
    
    public func getHint() -> String? {
        // Get a hint for the current rhythms
        if let firstRhythm = rhythmGenerator.rhythms.first, hintsUsed == 0 {
            hintsUsed += 1
            let needsLetterA = firstRhythm == .rest || firstRhythm == .crotchet
            return "The first rhythm is\(needsLetterA ? " a" : "") \(firstRhythm.rawValue.lowercased())"
        } else if let lastRhythm = rhythmGenerator.rhythms.last, hintsUsed == 1 {
            hintsUsed += 1
            let needsLetterA = lastRhythm == .rest || lastRhythm == .crotchet
            return "The last rhythm is\(needsLetterA ? " a" : "") \(lastRhythm.rawValue.lowercased())"
        } else {
            return nil
        }
    }
}
