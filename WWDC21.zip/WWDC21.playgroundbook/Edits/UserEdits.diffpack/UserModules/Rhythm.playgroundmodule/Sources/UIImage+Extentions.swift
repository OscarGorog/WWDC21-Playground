import SwiftUI

/// Add's a tint color to a `UIImage` based of a `Color`. We use `Color` as this function will only be called from SwiftUI
public extension UIImage {
    func withColor(_ color: Color) -> UIImage {
        let imageRenderer = UIGraphicsImageRenderer(size: size)
        return imageRenderer.image { (context) in
            UIColor(color).setFill()
            self.draw(at: .zero)
            context.fill(CGRect(x: 0, 
                                y: 0, 
                                width: size.width, 
                                height: size.height), blendMode: .sourceAtop)
        }
    }
}
