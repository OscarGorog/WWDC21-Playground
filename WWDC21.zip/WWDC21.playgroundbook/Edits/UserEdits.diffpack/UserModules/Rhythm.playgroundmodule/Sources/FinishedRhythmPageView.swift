import SwiftUI
import SharedCode

/// A view that congratulates the user of finishing the rhythm portion of the playground
public struct FinishedRhythmPageView: View {
    
    public var playAgainBlock: () -> Void
    
    public var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .edgesIgnoringSafeArea(.all)
            VStack {
                CustomNavigationBar(rightContent: {
                    Button(action: playAgainBlock, label: {
                        Text("Play Again")
                            .foregroundColor(.blue)
                            .fontWeight(.semibold)
                    })
                })
                Spacer()
                VStack {
                    Image(uiImage: #imageLiteral(resourceName: "Rest.png").withColor(.blue))
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 100)
                    Text("Great job!")
                        .font(.title)
                        .fontWeight(.semibold)
                    Text("Move onto the next page to learn about pitch in AR!")
                        .lineLimit(nil)
                        .multilineTextAlignment(.center)
                }.padding()
                Spacer()
            }
        }
    }
}
